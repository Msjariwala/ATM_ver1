-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2024 at 02:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `Sr` int(11) NOT NULL,
  `pin` text NOT NULL,
  `date` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`Sr`, `pin`, `date`, `type`, `amount`) VALUES
(1, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Oct 18 23:11:51 IST 2024', 'DEPOSIT', '5000.00'),
(2, 'cf866614b6b18cda13fe699a3a65661b', 'Tue Oct 22 20:17:02 IST 2024', 'DEPOSIT', '2000.00'),
(7, 'cf866614b6b18cda13fe699a3a65661b', 'Tue Oct 22 23:47:18 IST 2024', 'DEPOSIT', '500.00'),
(8, '122e27d57ae8ecb37f3f1da67abb33cb', 'Tue Oct 22 23:48:45 IST 2024', 'DEPOSIT', '5100.00'),
(9, 'b53477c2821c1bf0da5d40e57b870d35', 'Tue Oct 22 23:50:10 IST 2024', 'DEPOSIT', '8500.00'),
(10, '122e27d57ae8ecb37f3f1da67abb33cb', 'Tue Oct 22 23:52:54 IST 2024', 'DEPOSIT', '300.00'),
(11, 'b53477c2821c1bf0da5d40e57b870d35', 'Tue Oct 22 23:55:29 IST 2024', 'DEPOSIT', '550.00'),
(12, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Oct 23 00:00:38 IST 2024', 'WITHDRAWAL', '450.00'),
(13, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 00:02:39 IST 2024', 'WITHDRAWAL', '300.00'),
(14, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Oct 23 00:04:00 IST 2024', 'WITHDRAWAL', '150.00'),
(15, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Oct 23 01:26:28 IST 2024', 'WITHDRAWAL', '250.00'),
(16, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:30:57 IST 2024', 'WITHDRAWAL', '1000'),
(17, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:35:06 IST 2024', 'WITHDRAWAL', '10000'),
(18, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:36:53 IST 2024', 'DEPOSIT', '10000.00'),
(19, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:37:38 IST 2024', 'WITHDRAWAL', '10000.00'),
(20, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:37:55 IST 2024', 'DEPOSIT', '10000.00'),
(21, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 08:58:36 IST 2024', 'WITHDRAWAL', '1000'),
(22, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:46:48 IST 2024', 'DEPOSIT', '200.00'),
(23, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:47:15 IST 2024', 'WITHDRAWAL', '100'),
(24, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:48:39 IST 2024', 'DEPOSIT', '10000'),
(25, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:48:44 IST 2024', 'DEPOSIT', '10000'),
(26, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:48:47 IST 2024', 'DEPOSIT', '10000'),
(27, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 17:48:51 IST 2024', 'DEPOSIT', '10000'),
(28, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 18:01:11 IST 2024', 'WITHDRAWAL', '1200'),
(29, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 18:03:18 IST 2024', 'WITHDRAWAL', '1200.00'),
(30, '122e27d57ae8ecb37f3f1da67abb33cb', 'Wed Oct 23 18:15:13 IST 2024', 'WITHDRAWAL', '1000.00'),
(31, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Oct 23 18:37:23 IST 2024', 'DEPOSIT', '1000.00'),
(32, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Oct 23 18:38:26 IST 2024', 'WITHDRAWAL', '50.00'),
(33, 'cf866614b6b18cda13fe699a3a65661b', 'Wed Nov 13 18:19:28 IST 2024', 'DEPOSIT', '400.00'),
(34, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 17:53:12 IST 2024', 'DEPOSIT', '100.00'),
(35, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 17:54:42 IST 2024', 'DEPOSIT', '100.00'),
(36, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 17:56:32 IST 2024', 'WITHDRAWAL', '100'),
(37, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 17:56:51 IST 2024', 'WITHDRAWAL', '100.00'),
(38, '122e27d57ae8ecb37f3f1da67abb33cb', 'Thu Nov 14 19:50:11 IST 2024', 'WITHDRAWAL', '800.00'),
(39, '122e27d57ae8ecb37f3f1da67abb33cb', 'Thu Nov 14 19:51:43 IST 2024', 'WITHDRAWAL', '1000.00'),
(40, '122e27d57ae8ecb37f3f1da67abb33cb', 'Thu Nov 14 19:52:33 IST 2024', 'WITHDRAWAL', '1000.00'),
(41, '122e27d57ae8ecb37f3f1da67abb33cb', 'Thu Nov 14 19:55:30 IST 2024', 'WITHDRAWAL', '1000.00'),
(42, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 19:58:23 IST 2024', 'DEPOSIT', '500.00'),
(43, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Nov 14 19:59:18 IST 2024', 'WITHDRAWAL', '1000'),
(44, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Thu Nov 14 20:01:48 IST 2024', 'DEPOSIT', '2000.00'),
(45, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 20:35:41 IST 2024', 'DEPOSIT', '100.00'),
(46, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 21:03:41 IST 2024', 'DEPOSIT', '50.00'),
(47, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 21:06:57 IST 2024', 'DEPOSIT', '50.00'),
(48, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 21:08:37 IST 2024', 'DEPOSIT', '50.00'),
(49, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 22:08:04 IST 2024', 'WITHDRAWAL', '100.00'),
(50, 'b53477c2821c1bf0da5d40e57b870d35', 'Thu Nov 14 22:09:09 IST 2024', 'WITHDRAWAL', '2000'),
(51, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Thu Nov 14 22:15:00 IST 2024', 'WITHDRAWAL', '100.00'),
(52, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 13:42:51 IST 2024', 'WITHDRAWAL', '500'),
(53, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 13:48:44 IST 2024', 'DEPOSIT', '1550.50'),
(54, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 13:49:34 IST 2024', 'WITHDRAWAL', '550.00'),
(55, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 13:50:00 IST 2024', 'WITHDRAWAL', '40.00'),
(56, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 14:38:22 IST 2024', 'WITHDRAWAL', '100'),
(57, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 18:22:25 IST 2024', 'DEPOSIT', '250.00'),
(58, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 18:22:32 IST 2024', 'WITHDRAWAL', '100'),
(59, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 23:22:28 IST 2024', 'DEPOSIT', '155.0'),
(60, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 15 23:22:59 IST 2024', 'WITHDRAWAL', '50.00'),
(61, 'cf866614b6b18cda13fe699a3a65661b', 'Sat Nov 16 19:06:20 IST 2024', 'WITHDRAWAL', '100'),
(62, 'cf866614b6b18cda13fe699a3a65661b', 'Tue Nov 19 22:17:09 IST 2024', 'WITHDRAWAL', '15.00'),
(63, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Sat Nov 23 15:41:55 IST 2024', 'DEPOSIT', '780.57'),
(64, 'cf866614b6b18cda13fe699a3a65661b', 'Fri Nov 29 10:54:20 IST 2024', 'DEPOSIT', '100.00'),
(65, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Fri Nov 29 11:39:35 IST 2024', 'DEPOSIT', '120.00'),
(66, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Fri Nov 29 11:39:45 IST 2024', 'WITHDRAWAL', '20.00'),
(67, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'Fri Nov 29 11:39:52 IST 2024', 'WITHDRAWAL', '500'),
(68, 'cf866614b6b18cda13fe699a3a65661b', 'Thu Dec 26 22:32:11 IST 2024', 'DEPOSIT', '100.5'),
(78, ' 5706', 'Fri Dec 27 17:12:58 IST 2024', 'DEPOSIT', '2000.00'),
(79, ' 5706', 'Fri Dec 27 17:13:40 IST 2024', 'WITHDRAWAL', '500'),
(80, 'fa246d0262c3925617b0c72bb20eeb1d', 'Fri Dec 27 17:57:40 IST 2024', 'DEPOSIT', '1230.00'),
(81, '601ac804ce8eac52499a1cde96bae911', 'Fri Dec 27 18:27:36 IST 2024', 'DEPOSIT', '1000.00'),
(82, '601ac804ce8eac52499a1cde96bae911', 'Fri Dec 27 18:36:12 IST 2024', 'WITHDRAWAL', '100.00'),
(83, 'cf866614b6b18cda13fe699a3a65661b', 'Sun Dec 29 12:46:39 IST 2024', 'WITHDRAWAL', '100'),
(84, 'cf866614b6b18cda13fe699a3a65661b', 'Sun Dec 29 12:48:15 IST 2024', 'WITHDRAWAL', '100.00'),
(85, '4d2e7bd33c475784381a64e43e50922f', 'Sun Dec 29 12:59:13 IST 2024', 'DEPOSIT', '2000.00'),
(86, '4d2e7bd33c475784381a64e43e50922f', 'Sun Dec 29 12:59:36 IST 2024', 'DEPOSIT', '1000.00'),
(87, '4d2e7bd33c475784381a64e43e50922f', 'Sun Dec 29 12:59:56 IST 2024', 'WITHDRAWAL', '500.00'),
(88, '4d2e7bd33c475784381a64e43e50922f', 'Sun Dec 29 13:00:11 IST 2024', 'WITHDRAWAL', '100');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `cardNo` text NOT NULL,
  `pin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`cardNo`, `pin`) VALUES
('4567890123456789', '3b712de48137572f3849aabd5666a4e3'),
('4496729582401836', '122e27d57ae8ecb37f3f1da67abb33cb'),
('9168427588269011', 'fc4ddc15f9f4b4b06ef7844d6bb53abf'),
('5813956490174441', 'cf866614b6b18cda13fe699a3a65661b'),
('2637669480156027', 'b53477c2821c1bf0da5d40e57b870d35'),
('1409962945732575', '601ac804ce8eac52499a1cde96bae911'),
('1409962943830260', '4d2e7bd33c475784381a64e43e50922f');

-- --------------------------------------------------------

--
-- Table structure for table `netbalance`
--

CREATE TABLE `netbalance` (
  `srno` int(11) NOT NULL,
  `pin` text NOT NULL,
  `amount` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `netbalance`
--

INSERT INTO `netbalance` (`srno`, `pin`, `amount`) VALUES
(4, 'cf866614b6b18cda13fe699a3a65661b', '8001.0'),
(5, '122e27d57ae8ecb37f3f1da67abb33cb', '36000.0'),
(6, 'b53477c2821c1bf0da5d40e57b870d35', '7200.0'),
(7, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', '2280.57'),
(10, '601ac804ce8eac52499a1cde96bae911', '900.0'),
(11, '4d2e7bd33c475784381a64e43e50922f', '2400.0');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `form_no` varchar(30) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `DOB` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Marit_status` varchar(30) NOT NULL,
  `Addresss` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip_code` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`form_no`, `uname`, `fname`, `DOB`, `Gender`, `Email`, `Marit_status`, `Addresss`, `city`, `zip_code`, `state`) VALUES
(' 3460', 'Mohit Jariwala', 'Shailesh Jariwala', '10 Dec 2024', 'Male', 'Jari@gmail.com', 'Unmarried', 'Adajan,Surat', 'Surat', '395009', 'Gujarat'),
(' 2065', 'Mohit Jariwala', 'Shailesh Jariwala', '8 Feb 2005', 'Male', 'jari123@gmail.com', 'Unmarried', '123-sector3,Adajan,Surat', 'Surat', '395009', 'Gujarat'),
(' 3193', 'Mohit Jari', 'Shailesh Jari', '9 Dec 2024', 'Male', 'j123@gmail.com', 'Unmarried', '123-sector23,adajan', 'Surat', '395002', 'Gujarat'),
(' 7539', 'asdfj', 'wer', '11 Dec 2024', 'Male', 'ertg@gmail.com', 'Unmarried', 'asdf', 'asdfasdf', '2345', 'asdf'),
(' 1465', 'fghj', 'fghj', '11 Dec 2024', 'Male', 'fghj', 'Unmarried', 'fghj', 'asdf', '0987', 'guj'),
(' 1705', 'mohit', 'shailesh', '10 Dec 2024', 'Male', 'lksjdf', 'Unmarried', 'adajan', 'surat', '395009', 'Gujarat'),
(' 7974', 'asdfasdf', 'asdf', '11 Dec 2024', 'Male', 'asdf@sdf.com', 'Unmarried', 'asdf', 'fhj', '345677', 'asdf'),
(' 4434', 'lllll', 'lllll', '9 Dec 2024', 'Male', 'ppppp', 'Unmarried', 'lllll', 'lllll', '89000', 'lllll'),
(' 2277', 'kkkkkkk', 'kkkkk', '8 Dec 2024', 'Male', 'kkkk', 'Unmarried', 'kkkk', 'kkkk', '0000', 'kkkk'),
(' 1321', 'zzzzzz', 'zzzzzz', '9 Dec 2024', 'Male', 'zzzzz', 'Unmarried', 'zzzzz', 'zzzzz', 'zzzzz', 'zzzzz'),
(' 1606', 'aaaa', 'aaaa', '5 Dec 2024', 'Male', 'aaaa', 'Unmarried', 'aaaa', 'aaaa', '9999', 'aaaa'),
(' 705', 'Jariwala Mohit', 'Jariwala Shaileshkumar', '8 Feb 2005', 'Male', 'jm2005@gmail.com', 'Unmarried', 'parshuram Garden,Adajan,Surat', 'Surat', '395009', 'Gujarat');

-- --------------------------------------------------------

--
-- Table structure for table `signup2`
--

CREATE TABLE `signup2` (
  `form_no` varchar(30) NOT NULL,
  `religion` varchar(30) NOT NULL,
  `category` varchar(20) NOT NULL,
  `income` varchar(30) NOT NULL,
  `education` varchar(30) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `PAN` varchar(30) NOT NULL,
  `aadhar` varchar(30) NOT NULL,
  `sen_citizen` varchar(10) NOT NULL,
  `exAccnt` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup2`
--

INSERT INTO `signup2` (`form_no`, `religion`, `category`, `income`, `education`, `occupation`, `PAN`, `aadhar`, `sen_citizen`, `exAccnt`) VALUES
(' 2065', 'Hindu', 'OBC', 'Null', 'Non-Graduate', 'Student', '180013134567', '123409875677', 'NO', 'null'),
(' 3193', 'Hindu', 'OBC', 'Null', 'Non-Graduate', 'Student', '243508976859', '278846550977', 'NO', 'null'),
(' 7539', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '123434565678', '345345656788', 'NO', 'null'),
(' 1465', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '234345654', '123345546', 'NO', 'null'),
(' 1705', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '986885575757575', '101010101010101', 'NO', 'null'),
(' 7974', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '4567567877', '3456345633', 'NO', 'null'),
(' 4434', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '89999', '88888', 'NO', 'null'),
(' 2277', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '999999', '999999', 'NO', 'null'),
(' 1321', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '11111111', '11111111', 'NO', 'null'),
(' 1606', 'Hindu', 'General', 'Null', 'Non-Graduate', 'Salaried', '99999', '00000', 'NO', 'null'),
(' 705', 'Hindu', 'OBC', '<5,00,00', 'Non-Graduate', 'Student', '18001818242456', '18233494960602', 'NO', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `signup3`
--

CREATE TABLE `signup3` (
  `form_no` varchar(30) NOT NULL,
  `account_type` varchar(30) NOT NULL,
  `card_number` text NOT NULL,
  `pin` text NOT NULL,
  `facility` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup3`
--

INSERT INTO `signup3` (`form_no`, `account_type`, `card_number`, `pin`, `facility`) VALUES
('', 'Saving Account', ' 1409963070787750', 'c84e374bbe4f19a728b69bb7658c4b66', 'ATM CARD '),
('', 'Saving Account', ' 1409963042757480', '8cfa9a563aebef6a2020c03d56ea8fbf', 'ATM CARD '),
(' 2065', 'Saving Account', ' 1409963066702116', 'e2e7ec91120736529f1ebd7749ece05a', 'ATM CARD '),
(' 3193', 'Current Account', ' 1409962961527274', 'a7e4ac9e655b78408502d6f81d5324f7', 'ATM CARD '),
(' 7539', 'Recurring Deposit Account', ' 1409963000515589', ' 872', 'ATM CARD '),
(' 1465', 'Saving Account', ' 1409962912872158', ' 2655', 'ATM CARD '),
(' 1705', 'Saving Account', ' 1409963015556809', ' 3138', 'ATM CARD '),
(' 7974', 'Recurring Deposit Account', ' 1409962960443405', ' 3083', 'ATM CARD '),
(' 4434', 'Recurring Deposit Account', ' 1409962947707136', ' 3878', 'ATM CARD '),
(' 2277', 'Recurring Deposit Account', ' 1409963048033412', ' 5706', 'ATM CARD '),
(' 1321', 'Saving Account', '1409962984876623', '6405', 'ATM CARD '),
(' 1606', 'Recurring Deposit Account', '1409962945732575', '71cc107d2e0408e60a3d3c44f47507bd', 'ATM CARD '),
(' 705', 'Saving Account', '1409962943830260', 'be26abe76fb5c8a4921cf9d3e865b454', 'ATM CARD ');

-- --------------------------------------------------------

--
-- Table structure for table `totaldeposits`
--

CREATE TABLE `totaldeposits` (
  `srno` int(11) NOT NULL,
  `pin` text NOT NULL,
  `type` text NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totaldeposits`
--

INSERT INTO `totaldeposits` (`srno`, `pin`, `type`, `amount`) VALUES
(3, 'cf866614b6b18cda13fe699a3a65661b', 'DEPOSIT', '11756'),
(8, '122e27d57ae8ecb37f3f1da67abb33cb', 'DEPOSIT', '65600'),
(9, 'b53477c2821c1bf0da5d40e57b870d35', 'DEPOSIT', '9300'),
(10, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'DEPOSIT', '2900.57'),
(19, '601ac804ce8eac52499a1cde96bae911', 'DEPOSIT', '1000.00'),
(20, '4d2e7bd33c475784381a64e43e50922f', 'DEPOSIT', '3000');

-- --------------------------------------------------------

--
-- Table structure for table `totalwithdraws`
--

CREATE TABLE `totalwithdraws` (
  `srno` int(11) NOT NULL,
  `pin` text NOT NULL,
  `type` text NOT NULL,
  `amount` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalwithdraws`
--

INSERT INTO `totalwithdraws` (`srno`, `pin`, `type`, `amount`) VALUES
(4, 'cf866614b6b18cda13fe699a3a65661b', 'WITHDRAWAL', '3755'),
(5, '122e27d57ae8ecb37f3f1da67abb33cb', 'WITHDRAWAL', '29600'),
(6, 'b53477c2821c1bf0da5d40e57b870d35', 'WITHDRAWAL', '2100'),
(7, 'fc4ddc15f9f4b4b06ef7844d6bb53abf', 'WITHDRAWAL', '620'),
(8, '3b712de48137572f3849aabd5666a4e3', 'WITHDRAWAL', '0'),
(11, '601ac804ce8eac52499a1cde96bae911', 'WITHDRAWAL', '100'),
(12, '4d2e7bd33c475784381a64e43e50922f', 'WITHDRAWAL', '600');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`Sr`);

--
-- Indexes for table `netbalance`
--
ALTER TABLE `netbalance`
  ADD PRIMARY KEY (`srno`);

--
-- Indexes for table `totaldeposits`
--
ALTER TABLE `totaldeposits`
  ADD PRIMARY KEY (`srno`);

--
-- Indexes for table `totalwithdraws`
--
ALTER TABLE `totalwithdraws`
  ADD PRIMARY KEY (`srno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `Sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `netbalance`
--
ALTER TABLE `netbalance`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `totaldeposits`
--
ALTER TABLE `totaldeposits`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `totalwithdraws`
--
ALTER TABLE `totalwithdraws`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
